import { api } from "../api";

 

export const fetchJobDetails = (id) => {
  return async (dispatch) => {
    const url = `/jobs/${id}`;
    const response = await api
      .get(url)
      .then((res) => {
        return res;
      })
      .catch((error) => {
        return error.response;
      });

    dispatch({
      type: "FETCH_JOB_DETAILS",
      payload: response,
    });
  };
};

 