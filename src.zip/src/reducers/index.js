import { combineReducers } from "redux";

 
const detailsDataReducer = (
  state = {
    job_details: {},
    
  },

  action
) => {
  switch (action.type) {
    case "FETCH_JOB_DETAILS": {
      if (action.payload.status === 200) {
        let newState = { ...state, job_details: action.payload.data };
        return newState;
      } else {
        let newState = { ...state, job_details: {} };
        return newState;
      }
    }
 
    default:
      return state;
  }
};
 

export default combineReducers({
  
  detailsData: detailsDataReducer,
   
});
