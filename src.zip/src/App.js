 

 

import React from "react";
import { Provider } from "react-redux";
import store from "./store/Store";

import { BrowserRouter, Switch, Route } from "react-router-dom";

// styles
import './index.css';
import './styles/tailwind.generated.css'
// import "./components/styles/tailwind.generated.css";
// import "./components/styles/tailwind.css";
 
 
 
 
import HomeScreen from "./components/HomeScreen";
import Homepage from "./components/Homepage";
import JobDetails2 from "./components/JobDetails2";

const App = () => {
  return (
    <Provider store={store}>
      <BrowserRouter >
        <Switch>
          
     
            <Route exact path="/">
             
            <Homepage />
          </Route>
            <Route exact path="/job-details/:id">
             
             <JobDetails2 />
             </Route>
            
          
         
        </Switch>   
      </BrowserRouter>
    </Provider>
  );
};
export default App;
