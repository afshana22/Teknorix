 

import React, { useState, useEffect } from "react";
 
 
function Department() {
    const [items, setItems] = React.useState([]);
    const [value, setValue] = React.useState( "R2-D2");
    const [loading, setLoading] = React.useState(true);
    React.useEffect(() => {
        let unmounted = false;
        async function getCharacters() {
          const response = await fetch(
            "https://teknorix.jobsoid.com/api/v1/departments"
          );
          const body = await response.json();
          if (!unmounted) {
            setItems(
              body.map(({ title }) => ({
                label: title,
                value: title
              }))
            );
            setLoading(false);
          }
        }
        getCharacters();
        return () => {
          unmounted = true;
        };
      }, []);

  return (
    <select  disabled={loading} placeholder ='Department' className='w-full'
    value={value}
    onChange={e => setValue(e.currentTarget.value)}>
         <option  >Department </option>
    {items.map(({ label, value }) => (
      <option key={value} value={value}>
        {label}
      </option>
    ))}
  </select>
  );
}

export default Department;
