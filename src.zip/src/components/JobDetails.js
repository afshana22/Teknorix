 
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
 

function JobDetails({name,department,type,location,applyUrl,newTo }) {
  

  return (
     <div className='mb-6 ' >
<h1 className='text-3xl font-bold'>
    {department}
</h1>
<h1 className='text-2xl font-bold'>
{name}
</h1>
<div className='md:flex justify-between' >
<div className='md:flex gap-6'> <i class='	far fa-building self-center'></i>	{department}<i class='fas fa-map-marker-alt self-center'></i>   {location}
<h1 className='bg-gray-300 p-1 rounded text-xs'>{type}</h1>
</div>
<div  className='flex gap-6' >
  <Link to ={applyUrl}>  <h1 className='border border-blue-500 rounded-lg pl-4 pr-4 pt-1 pb-1 font-semibold '>Apply</h1></Link> <Link to ={newTo}> <h1 className='font-semibold'>View</h1> </Link>
</div>
</div>
         </div>
  );
}

export default JobDetails;
