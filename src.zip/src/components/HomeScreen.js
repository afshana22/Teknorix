 
import React, { useState, useEffect } from "react";
import Department from "./Department";
import Homepage from "./Homepage";
import Location from './Location'
import Function from './Function'
function HomeScreen({name,salary,experience }) {
  

  return (
 <>
 <div className='p-10 bg-gray-300'><Homepage /></div>
 <div className='p-10 bg-gray-300 grid grid-cols-3 gap-6'><Department /> <Location /> <Function /> </div>
 </>
  );
}

export default HomeScreen;
