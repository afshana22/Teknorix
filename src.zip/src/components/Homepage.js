// import React, { Component } from 'react';

// export default class Homepage extends Component {
//   render() {
//     return (
//       <div> textInComponent </div>
//     );
//   }
// }


import React, { useState, useEffect } from "react";
import JobDetails from "./JobDetails";
import Department from "./Department";
 
import Location from './Location'
import Function from './Function'
function Homepage() {
  const [item, SearchData] = useState([]);
  const [cryptos, setCryptos] = useState([]);
  const [origCryptosCount, setOrigCryptosCount] = useState([]);

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const url = "https://teknorix.jobsoid.com/api/v1/jobs";
    const response = await fetch(url);
    const info = await response.json();
    setCryptos(info);
    setOrigCryptosCount(info);
  };

 
  const Search = key => {
    const newResults = origCryptosCount.filter(crypto => crypto.title.includes(key));
    console.log('newResults', newResults);
    setCryptos(newResults);
  };

  const cryptoJsx = cryptos.map(crypto => (
    // <div key={crypto.id}>{crypto.title}</div>
    <JobDetails newTo={`job-details/${crypto.id}`} location={crypto.location.title} applyUrl ={crypto.applyUrl} key={crypto.id} name = {crypto.title} department = {crypto.department.title} type = {crypto.type} />
  ));

  return (
    <div>
       
       <div className='p-10 bg-gray-300'>     <input placeholder ="Search Job" type="text" onChange={event => Search(event.target.value)} className='border-2 w-full p-2' />
       
   </div>
      <div className='p-10 bg-gray-300 grid grid-cols-3 gap-6'><Department /> <Location /> <Function /> </div>
      <div className='m-10 bg-white'>
      {cryptoJsx}
      </div>
    </div>
  );
}

export default Homepage;
