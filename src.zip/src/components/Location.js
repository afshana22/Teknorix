// import React, { Component } from 'react';

// export default class Homepage extends Component {
//   render() {
//     return (
//       <div> textInComponent </div>
//     );
//   }
// }


import React, { useState, useEffect } from "react";
 
 
function Location() {
    const [items, setItems] = React.useState([]);
    const [value, setValue] = React.useState( "R2-D2");
    const [loading, setLoading] = React.useState(true);
    React.useEffect(() => {
        let unmounted = false;
        async function getCharacters() {
          const response = await fetch(
            "https://teknorix.jobsoid.com/api/v1/locations"
          );
          const body = await response.json();
          if (!unmounted) {
            setItems(
              body.map(({ title }) => ({
                label: title,
                value: title
              }))
            );
            setLoading(false);
          }
        }
        getCharacters();
        return () => {
          unmounted = true;
        };
      }, []);

  return (
    <select  disabled={loading} placeholder ='Location' className='w-full'
    value={value}
    onChange={e => setValue(e.currentTarget.value)}>
        <option  >Location </option>
    {items.map(({ label, value }) => (
        
      <option key={value} value={value}>
        {label}
      </option>
    ))}
  </select>
  );
}

export default Location;
