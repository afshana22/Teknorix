import React, { Component } from "react";
 
import { Link, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import { fetchJobDetails } from "../actions";
import SideDetails from './SideDetails'
class JobDetails2 extends Component {
 

  componentDidMount() {
 
    this.props.fetchJobDetails(this.props.match.params.id);
  }
  createMarkup = (body) => {
    return { __html: body };
  };

  render() {
 let job_data = this.props.job_details
    return (
        <div>
            <div className="m-10  " key ={job_data.id}>
                <div className='mb-6 ' >
                    <h1 className='text-3xl font-bold'>
                    {job_data && job_data.department ? job_data.department.title : null} At {job_data ? job_data.title : null}
                    </h1>
                    <h1 className='text-2xl font-bold'>
                    {job_data ? job_data.title : null}
                    </h1>
                
                    <div className='md:flex gap-6'> <i class='	far fa-building self-center'></i>	 {job_data && job_data.department ? job_data.department.title : null}<i class='fas fa-map-marker-alt self-center'></i>   {job_data && job_data.location ? job_data.location.title : null}
                        <h1 className='bg-gray-300 p-1 rounded text-xs'>{job_data.type}</h1>
                    </div>
                    <Link to ={job_data.applyUrl}>  <h1 className='border mt-10 bg-blue-500 rounded-lg pl-4 pr-4 pt-1 pb-1 font-semibold text-white w-48 text-center '>Apply</h1></Link>    
                </div>
        
                <div  className='grid grid-cols-3'>
                <div
                        className="  ml-2 mb-4   text-xl col-span-2"
                        dangerouslySetInnerHTML={this.createMarkup(
                            job_data ? job_data.description : null
                        )}
                    ></div>
                    <SideDetails />
                </div>
            </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    job_details: state.detailsData.job_details,
  
  };
};
export default withRouter(
  connect(mapStateToProps, {
    fetchJobDetails,
 
  })(JobDetails2)
);

 
