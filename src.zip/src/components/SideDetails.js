// import React, { Component } from 'react';

// export default class Homepage extends Component {
//   render() {
//     return (
//       <div> textInComponent </div>
//     );
//   }
// }


import React, { useState, useEffect } from "react";
import JobDetails from "./JobDetails";
import Department from "./Department";
 
import Location from './Location'
import Function from './Function'
function SideDetails() {
 
  const [cryptos, setCryptos] = useState([]);
 

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    const url = "https://teknorix.jobsoid.com/api/v1/jobs";
    const response = await fetch(url);
    const info = await response.json();
    setCryptos(info);
     
  };

 
 
  const cryptoJsx = cryptos.map(crypto => (
    <div key={crypto.id} className='mb-6'>
        <h1 className='  font-bold'>
        {crypto.title}
</h1>
<div className=' flex justify-between' >
<div className=' flex gap-6'> <i class='	far fa-building self-center'></i>	{crypto.department.title}<i class='fas fa-map-marker-alt self-center'></i>    {crypto.location.title}
    </div>
    </div>
    </div>
    
  ));

  return (
    <div className=' pt-10 pb-5  '>
       
        <div className='bg-gray-400 pb-5'>

       
      <h1 className='text-2xl font-bold text-center'>Other Job Openings</h1>
      <div className='m-10  '>
      {cryptoJsx}
      </div>
      </div>
      <h1 className='text-2xl font-bold text-center'>Share Job Openings</h1>
      <a href="http://www.linkedin.com/company/teknorix"><img src="/download.png" className='h-10'/></a>
    </div>
  );
}

export default SideDetails;
